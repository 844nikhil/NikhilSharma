package com.cloud.dbservice.resource;

import java.util.List;

import javax.validation.Valid;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.cloud.dbservice.model.Details;

@RestController
@RequestMapping("/rest/db")
public class DbService {
	
	@Autowired
	private DetailsRepository detailsRepository;
	
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	 public List<Details> getAllUsers() {
	    return detailsRepository.findAll();
	 }
	
	@GetMapping("/{_id}")
	public Details getDetails(@PathVariable("_id") ObjectId _id ){
		return detailsRepository.findBy_id(_id);
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public Details add(@Valid @RequestBody Details details) {
		details.set_id(ObjectId.get());
		detailsRepository.save(details);
		return details;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void delete(@PathVariable ObjectId id) {
		detailsRepository.delete(detailsRepository.findBy_id(id));
		
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Details update(@PathVariable("id") ObjectId id, @Valid @RequestBody Details details) {
		details.set_id(id);
		detailsRepository.save(details);
		return details;
	}
	
	@GetMapping(value="/submit")
	public ModelAndView submit(Model model, @ModelAttribute("name") String name, @ModelAttribute("age")String age) {
		ModelAndView mav=new ModelAndView();
		
		mav.setViewName("success");
		return mav;
	}
}
