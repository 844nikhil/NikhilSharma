package ev_lm_createLead

import (
	"github.com/labstack/echo"
	"net/http"
	"encoding/json"
	model "LeadMgmt/ev_lm_json"
	query "lib/database/query"
	//"strconv"
	//"fmt"
)

/*func IntConverter(id string) (int,error){

	//response:= model.ApiResponse{}

	intId, err:= strconv.Atoi(id)
	fmt.Println(intId)
	
	return intId,err
}*/


/*func CreateLeadHandler(c echo.Context) error {

	leadDetails := model.LeadDetails{}
	lead := model.Lead{}

	response:= model.ApiResponse{}

	defer c.Request().Body.Close()
	err_lead = json.NewDecoder(c.Request().Body).Decode(&leadDetails)

	lead.Id =leadDetails.Id
	lead.PrimaryUser = leadDetails.PrimaryUserDetails.HomeownerId
	lead.SecondaryUser = leadDetails.SecondaryUserDetails.HomeownerId
	lead.JobType = leadDetails.JobType
	lead.LeadStatus = leadDetails.LeadStatus
	lead.LeadSource = leadDetails.LeadSource
	lead.AssignedTo = leadDetails.AssignedToDetails.UserId
	lead.Address = leadDetails.AddressesDetails.AddressId
	lead.Status = leadDetails.Status
	lead.CompanyId=leadDetails.AssignedToDetails.CompanyId
	
	/*lead.Id, err= IntConverter(leadDetails.Id)
	lead.PrimaryUser, err= IntConverter(leadDetails.PrimaryUserDetails.HomeownerId)
	lead.SecondaryUser, err = IntConverter(leadDetails.SecondaryUserDetails.HomeownerId)
	lead.AssignedTo, err = IntConverter(leadDetails.AssignedToDetails.UserId)
	lead.Address, err = IntConverter(leadDetails.AddressesDetails.AddressId)
	lead.CompanyId, err = IntConverter(leadDetails.AssignedToDetails.CompanyId)

	if err_lead!= nil{
			/*response.Code=400
			response.Type = err.Error()
			response.Message="Invalid Input"
		log.Printf("Failed processing lead request body ",err_lead)
		return echo.NewHTTPError(http.StatusInternalServerError,"405")
	}else{
		response = query.CreateLeadQuery(lead)
		
		
		c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
		c.Response().WriteHeader(http.StatusOK)
	   
	}

	return json.NewEncoder(c.Response()).Encode(response)
}*/

func CreateLeadHandler(c echo.Context) error {

	leadDetails := model.LeadDetails{}
	lead := model.Lead{}

	response:= model.ApiResponse{}

	defer c.Request().Body.Close()
	err_lead := json.NewDecoder(c.Request().Body).Decode(&leadDetails)

	lead.Id =leadDetails.Id
	lead.PrimaryUser = leadDetails.PrimaryUserDetails.HomeownerId
	lead.SecondaryUser = leadDetails.SecondaryUserDetails.HomeownerId
	lead.JobType = leadDetails.JobType
	lead.LeadStatus = leadDetails.LeadStatus
	lead.LeadSource = leadDetails.LeadSource
	lead.AssignedTo = leadDetails.AssignedToDetails.UserId
	lead.Address = leadDetails.AddressesDetails.AddressId
	lead.Status = leadDetails.Status
	lead.CompanyId=leadDetails.AssignedToDetails.CompanyId
	
	if err_lead!= nil{
			response.Code=500
			response.Type = err_lead.Error()
			response.Message="Error in decoding JSON object"
			//return response
	}else{
		response = query.CreateLeadQuery(lead)
		
		
		c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
		c.Response().WriteHeader(http.StatusOK)
	   
	}

	return json.NewEncoder(c.Response()).Encode(response)
}