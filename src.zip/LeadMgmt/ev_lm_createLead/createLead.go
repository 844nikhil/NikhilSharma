package ev_lm_createLead

import (
	"github.com/labstack/echo"
	"net/http"
	"encoding/json"
	model "LeadMgmt/ev_lm_model"
	query "lib/database/query"
	"log"
)

func CreateLeadHandler(c echo.Context) error {

	leadDetails := model.LeadDetails{}
	lead := model.Lead{}
	response:= model.ApiResponse{}

	defer c.Request().Body.Close()
	err_lead := json.NewDecoder(c.Request().Body).Decode(&leadDetails)
	log.Println(err_lead)
	if err_lead!=nil {
		response.Code=405
		response.Type=err_lead.Error()
		response.Message="Invalid Input"
	}else{
		log.Println("lead: %s",leadDetails)
		lead.Id=leadDetails.Id
		lead.ConvertedToOpportunity=leadDetails.ConvertedToOpportunity
		lead.PrimaryUser=leadDetails.PrimaryUserDetails.HomeOwnerId
		lead.SecondaryUser=leadDetails.SecondaryUserDetails.HomeOwnerId
		lead.JobType = leadDetails.JobType
		
		lead.LeadStatus = leadDetails.LeadStatus
		lead.LeadSource = leadDetails.LeadSource
		lead.AssignedTo=leadDetails.AssignedToDetails.UserId
		lead.Address=leadDetails.AddressesDetails.AddressId
		lead.LeadStatus = leadDetails.LeadStatus
		//log.Println("lead: %s",lead)

		dberr:= query.CreateLeadQuery(lead)
		//log.Println(dberr)
		if dberr!=nil {
			response.Code=400
    	    response.Type=dberr.Error()
			response.Message="Data Insertion Failed"
		}else{
			response.Code=200
    	    response.Type="Success"
			response.Message="OK"
		}
	}
		
	c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
	c.Response().WriteHeader(http.StatusOK)

	return json.NewEncoder(c.Response()).Encode(response)
}