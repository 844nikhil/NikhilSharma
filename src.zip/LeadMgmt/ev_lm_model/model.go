//This package defines Lead Management json data model
package ev_lm_model

type ApiResponse struct {
	Code            int 		 `json:"code"`
    Type            string 		 `json:"type"`
    Message         string 		 `json:"message"`
}

type LeadDetails struct{
    Id                          int           `json:"id"`
    ConvertedToOpportunity      bool        `json:"convertedToOpportunity"`
    PrimaryUserDetails          Homeowner     `json:"primaryUser"`
    SecondaryUserDetails        Homeowner    `json:"secondaryUser"`
    JobType                     string           `json:"jobType"`
    LeadSource                  string           `json:"leadSource"`
    AssignedToDetails           User       `json:"assignedTo"`
    AddressesDetails            Address          `json:"address"`
    LeadStatus                  string           `json:"leadStatus"`
    
}



type User struct{
    UserId          int      `json:"userId" gorm:"column:UserId" gorm:"primary_key"`
    CompanyId       int      `json:"companyId" gorm:"column:CompanyId"`
}

type Address struct{
    AddressId            int      `json:"addressId" gorm:"column:AddressID" gorm:"primary_key"`
    EvMeasurementStatus  string   `json:"evMeasurementStatus" gorm:"column:EvMeasurementStatus"`
    AddressLine1         string   `json:"addressLine1" gorm:"column:AddressLine1"`
    AddressLine2         string   `json:"addressLine2" gorm:"column:AddressLine2"`
    City                 string   `json:"city" gorm:"column:City"` 
    State                string   `json:"state" gorm:"column:State"`
    Zip                  int      `json:"zip" gorm:"column:Zip"`
}


type Lead struct {
    Id                          int         `json:"id" gorm:"column:ID" gorm:"primary_key"`
    ConvertedToOpportunity      bool        `json:"convertedToOpportunity" gorm:"column:ConvertedToOpportunity"`
    PrimaryUser                 int         `json:"primaryUser" gorm:"column:PrimaryUser"`
    SecondaryUser               int         `json:"secondaryUser" gorm:"column:SecondaryUser"` 
    JobType                     string      `json:"jobType" gorm:"column:JobType"`
    LeadSource                  string      `json:"leadSource" gorm:"column:LeadSource"` 
    AssignedTo                  int         `json:"assignedTo" gorm:"column:AssignedTo"`
    Address                     int         `json:"address" gorm:"column:Address"`
    LeadStatus                  string      `json:"leadStatus" gorm:"column:LeadStatus"`
    
}

type Homeowner struct {
    HomeOwnerId     int         `json:"homeownerId" gorm:"column:HomeOwnerID" gorm:"primary_key"`
    UserName        string      `json:"username" gorm:"column:UserName"`
    FirstName	    string      `json:"firstName" gorm:"column:FirstName"`
    LastName	    string      `json:"lastName" gorm:"column:LastName"`
    HomePhone	    string      `json:"homePhone" gorm:"column:HomePhone"`
    MobilePhone     string      `json:"mobilePhone" gorm:"column:MobilePhone"`
    Email	        string      `json:"email" gorm:"column:Email"`
    UserStatus	    bool 	    `json:"userStatus" gorm:"column:UserStatus"`
    CustomNotes     string      `json:"customNotes" gorm:"column:CustomNotes"`
    HouseholdType   bool      `json:"householdType" gorm:"column:HouseholdType"`
}


