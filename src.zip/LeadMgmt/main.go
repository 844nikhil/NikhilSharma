/**
* 
*
* @author  Capgemini
* @version v1
* @since   2019-22-05
*/
package main

import (
	"github.com/labstack/echo"
	db "lib/database/dbLayer"
	config "lib/configuration"
	query "LeadMgmt/ev_lm_createLead"

)
/*
//This function decodes the json object recieved from the request
func jsonDecode(c echo.Context) error {
	lead := ev_lm_json.Lead{}
	defer c.Request().Body.Close()
	err := json.NewDecoder(c.Request().Body).Decode(&lead)
	if err != nil{
		log.Printf("Failed processing request body in lead body : %s", err)
		return echo.NewHTTPError(http.StatusInternalServerError) //sends error object with help of echo package
	}
	log.Printf("this is decoded json object: %s",lead) 
	return c.String(http.StatusOK,fmt.Sprintf("%s", lead))

}

//This function encodes data retrieved from database to json object 
func jsonEncode(c echo.Context) error {

	//Dummy JSON Object
	primaryUser := &ev_lm_json.PrimaryUser{
		HomeownerId : "1",
    	Username : "username",
    	FirstName : "firstname",
    	LastName : "lastname",
    	Phone : "9876543210",
		Email : "email@eagleview.com",
		UserStatus : "true",
		CustomNotes : "abc",
    	HouseholdType : "Roofing",
	} 

	secondaryUser := &ev_lm_json.SecondaryUser{
		HomeownerId : "2",
    	Username : "username",
    	FirstName : "firstname",
    	LastName : "lastname",
    	Phone : "9876543210",
		Email : "email@eagleview.com",
		UserStatus : "true",
		CustomNotes : "abc",
    	HouseholdType : "Roofing",
	} 

	address := &ev_lm_json.Address{
		AddressId: "1",
		AddressLine1 : "Mount Embassy",
		AddressLine2 : "Avenue",
		State : "Albany",
		City : "NewYork",
		Zip : "10001",
	}

	assignedTo := &ev_lm_json.AssignedTo{
		UserId : "1",
		CompanyId : "1",
	}

	lead := &ev_lm_json.Lead{
		Id : "leadId",
		PrimaryUser : []ev_lm_json.PrimaryUser{*primaryUser},
		SecondaryUser : []ev_lm_json.SecondaryUser{*secondaryUser},
    	JobType : "jobType",
		LeadStatus : "leadStatus", 	
		LeadSource : "leadSource",
		AssignedToID : []ev_lm_json.AssignedTo{*assignedTo},
    	Address : []ev_lm_json.Address{*address},
    	Status : "leadStatus",
	}

	c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
  	c.Response().WriteHeader(http.StatusOK)
  	return json.NewEncoder(c.Response()).Encode(lead)
}
*/
func main() {
	//confPath := flag.String("conf", `.\config\config.json`, "flag to set the path to the configuration json file")
	//flag.Parse()
	//extract configuration
	config, _ := config.ExtractConfiguration(/**confPath*/)
	connection := db.ConnectToDatabase(config)
	
	defer connection.Close()
	e := echo.New()
	//e.POST("/jsonDecode", jsonDecode)
	//e.GET("/jsonEncode", jsonEncode)
	//e.POST("/createAddress",query.CreateAddress)
	e.POST("/createLead",query.CreateLead)
	//e.DELETE("/deleteAddress",query.DeleteAddress)
	e.Start(":8099")
	
}