//This package defines Lead Management json data model
package ev_lm_json


type PrimaryUser struct {
    HomeownerId  string  `json:"homeownerid"`
    Username    string   `json:"username"`
    FirstName	string   `json:"firstName"`
    LastName	string   `json:"lastName"`
    Phone	string       `json:"phone"`
    Email	string       `json:"email"`
    UserStatus	string 	 `json:"userStatus"`
    CustomNotes string   `json:"customNotes"`
    HouseholdType string `json:"householdType"`
}

type SecondaryUser struct {
    HomeownerId  string  `json:"homeownerid"`
    Username    string   `json:"username"`
    FirstName	string   `json:"firstName"`
    LastName	string   `json:"lastName"`
    Phone	string       `json:"phone"`
    Email	string       `json:"email"`
    UserStatus	string 	 `json:"userStatus"`
    CustomNotes string   `json:"customNotes"`
    HouseholdType string `json:"householdType"`
}

type AssignedTo struct{
    UserId string `json:"userId"`
    CompanyId string `json:"companyId"`
}

type Address struct{
    AddressId string `json:"addressId"`
    AddressLine1 string `json:"addressLine1"`
    AddressLine2 string `json:"addressLine2"`
    City string `json:"city"` 
    State string `json:"state"`
    Zip string `json:"zip"`
}

type Lead struct {
    Id string              `json:"id"`
    PrimaryUser string `json:"primaryUser"`
    SecondaryUser string `json:"secondaryUser"`
    JobType string      `json:"jobType"`
    LeadStatus string   `json:"leadStatus"`
    LeadSource string   `json:"leadSource"`
    AssignedToID string   `json:"assignedTo"`
    Address	string     `json:"address"`
    Status string       `json:"status"`
}

type ApiResponse struct {
	Code int 		    `json:"code"`
    Type string 		`json:"type"`
    Message string 		`json:"message"`
}