package query
import(
	model "LeadMgmt/ev_lm_model"
)


func CreateLeadTable() {
	 db.AutoMigrate(&model.Lead{}, &model.Homeowner{}, &model.User{}, &model.Address{} )
	 
}