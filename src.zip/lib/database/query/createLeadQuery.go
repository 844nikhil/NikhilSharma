package query

import (
	model "LeadMgmt/ev_lm_json"
	"strconv"
	"fmt"
)


/*func IntConverter(id string) (int,model.ApiResponse){

	response:= model.ApiResponse{}

	intId, err:= strconv.Atoi(id)
	fmt.Println(intId)
	if err!=nil{
		response.Code=400
		response.Type = err.Error()
		response.Message="Invalid Input"
	}
	return intId,response
}*/

func CreateLeadQuery(lead model.Lead) (model.ApiResponse) {
	
	response:= model.ApiResponse{}
	
	/*leadId, response:= IntConverter(lead.Id)
	primaryUserId, response:= IntConverter(lead.PrimaryUser)
	secondaryUserId, response := IntConverter(lead.SecondaryUser)
	assignedToId, response := IntConverter(lead.AssignedTo)
	addressId, response := IntConverter(lead.Address)*/
	
	primaryUserId, err:= strconv.Atoi(lead.PrimaryUser)
	fmt.Println(primaryUserId)
	if err!=nil{
		response.Code=400
		response.Type=err.Error()
		response.Message="Invalid Input"
		return response
	}
	secondaryUserId, err := strconv.Atoi(lead.SecondaryUser)
	if err!=nil{
		response.Code=400
		response.Type=err.Error()
		response.Message="Invalid Input"
		return response
	}
	assignedToId, err := strconv.Atoi(lead.AssignedTo)
	if err!=nil{
		response.Code=400
		response.Type=err.Error()
		response.Message="Invalid Input"
		return response
	} 
	addressId, err := strconv.Atoi(lead.Address)
	if err!=nil{
		response.Code=400
		response.Type=err.Error()
		response.Message="Invalid Input"
		return response
	} 
	leadId, err:= strconv.Atoi(lead.Id)
	if err!=nil{
				response.Code=400
				response.Type=err.Error()
				response.Message="Invalid Input"
		return response
	}
	companyId, err := strconv.Atoi(lead.CompanyId)
	if err!=nil{
		response.Code=400
		response.Type=err.Error()
		response.Message="Invalid Input"
		return response
	}
	_,err= db.Exec(`
		INSERT INTO public."LEADS" ("ID","PRIMARYUSER","SECONDARYUSER","JOBTYPE","LEADSTATUS","LEADSOURCE","ASSIGNEDTO","ADDRESS","STATUS","COMPANYID")
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,leadId,primaryUserId,secondaryUserId,lead.JobType,lead.LeadStatus,lead.LeadSource,assignedToId,addressId,lead.Status,companyId)
		fmt.Println(err)
		if err != nil {
			response.Code=400
			response.Type = err.Error()
			response.Message="ID Already Exists"
			return response
		}else{
			response.Code=200
        	response.Type="Success"
			response.Message="OK"
			return response
		}	
}