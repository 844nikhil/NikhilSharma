package query

import (
	model "LeadMgmt/ev_lm_model"
)

func CreateLeadQuery(lead model.Lead) (error) {
	dberr:=db.Create(&lead).Error
	return dberr
}