package query
import(
	"github.com/labstack/echo"
	"os"
)


func GetApiDocs(context echo.Context) error {
	gopath := os.Getenv("GOPATH")
	filepath := gopath+`\src\web\public\swagger.json`
	return context.File(filepath)
}


