package configuration

import (
	"encoding/json"
	"fmt"
	"os"
)

/*var (
	dbUserDefault     = "postgres"
	dbPassword = "eagleview"
	dbName     = "eagleviewdb" 
	port = "5432"
	host = "nimmyjose-eagleview-rdspostgresql.c3ii4gu0gpjw.eu-west-1.rds.amazonaws.com"
)*/

type ServiceConfig struct {
	DB_USER			string		`json:"dbUser"`
	DB_PASSWORD		string		`json:"dbPassword"`
	DB_NAME			string		`json:"dbName"`
	PORT			string		`json:"port"`
	HOST			string		`json:"host"`
}

func ExtractConfiguration(/*filename string*/) (ServiceConfig, error) {
	/*conf := ServiceConfig{
		dbUserDefault,
		dbPassword,
		dbName,
		port,
		host,
	}*/

	conf := ServiceConfig{
	}

	gopath := os.Getenv("GOPATH")
	filepath := gopath+`\src\lib\configuration\config.json`
	file, err := os.Open(filepath)
	if err != nil {
		fmt.Println("Configuration file not found. Continuing with default values.")
		fmt.Println(err)
		return conf,err
	}

	err = json.NewDecoder(file).Decode(&conf)
	return conf, err
}